let inputNum1 = document.querySelector("#InuputNum1")

let inputNum2 = document.querySelector("#InuputNum2")

let inputNum3 = document.querySelector("#InuputNum3")

let button = document.querySelector("#button")

let resultado = document.querySelector("#resultado")

function calculomedias(){

    let num1 = Number(inputNum1.value);
    let num2 = Number(inputNum2.value);
    let num3 = Number(inputNum3.value);

    let mediaaritimetica = (num1 + num2 + num3) / 3;

    let mediaponderada = ((num1 * 3) + (num2 * 2) + (num3 * 5)) / (3 + 2 + 5);

    let somaMedia = mediaaritimetica + mediaponderada;

    let mediaMedia = somaMedia / 2;

    resultado.innerHTML = "Média Aritimética: " +mediaaritimetica + "<br>";
                            "Média Ponderada: " +mediaponderada + "<br>";
                            "Soma das Medias: " +somaMedia+ "<br>";
                            "Média das medias: " +mediaMedia;
}

button.oncliick = function(){
    calculomedias();
}